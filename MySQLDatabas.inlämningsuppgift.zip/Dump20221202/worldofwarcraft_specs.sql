-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: worldofwarcraft
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `specs`
--

DROP TABLE IF EXISTS `specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specs` (
  `specs_id` int NOT NULL AUTO_INCREMENT,
  `specs_name` varchar(45) NOT NULL,
  `classes_classes_id` int NOT NULL,
  `roles_roles_id` int NOT NULL,
  `tiers_tiers_id` int NOT NULL,
  PRIMARY KEY (`specs_id`,`classes_classes_id`,`roles_roles_id`,`tiers_tiers_id`),
  KEY `fk_specs_classes1_idx` (`classes_classes_id`),
  KEY `fk_specs_roles2_idx` (`roles_roles_id`),
  KEY `fk_specs_tiers1_idx` (`tiers_tiers_id`),
  CONSTRAINT `fk_specs_classes1` FOREIGN KEY (`classes_classes_id`) REFERENCES `classes` (`classes_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_specs_roles2` FOREIGN KEY (`roles_roles_id`) REFERENCES `roles` (`roles_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_specs_tiers1` FOREIGN KEY (`tiers_tiers_id`) REFERENCES `tiers` (`tiers_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specs`
--

LOCK TABLES `specs` WRITE;
/*!40000 ALTER TABLE `specs` DISABLE KEYS */;
INSERT INTO `specs` VALUES (1,'Fury',1,3,3),(2,'Protection',1,1,3),(3,'Arms',1,3,3),(4,'Subtlety',2,3,4),(5,'Assassination',2,3,2),(6,'Combat',2,3,2),(7,'Holy',3,2,1),(8,'Retribution',3,3,3),(9,'Protection',3,1,1),(10,'Frost',4,4,4),(11,'Fire',4,4,3),(12,'Arcane',4,4,2),(13,'Holy',5,2,3),(14,'Discipline',5,2,2),(15,'Shadow',5,4,3),(16,'Affliction',6,4,1),(17,'Demonology',6,4,2),(18,'Destruction',6,4,2),(19,'Enhancement',7,3,2),(20,'Restoration',7,2,3),(21,'Elemental',7,4,3),(22,'Unholy',8,3,1),(23,'Frost',8,3,1),(24,'Blood',8,1,2),(25,'Beast mastery',9,4,4),(26,'Survival',9,4,2),(27,'Marksman',9,4,3),(28,'Restoration',10,2,2),(29,'Feral dps',10,3,2),(30,'Balance',10,4,3),(31,'Feral tank',10,1,3);
/*!40000 ALTER TABLE `specs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-02 14:45:30

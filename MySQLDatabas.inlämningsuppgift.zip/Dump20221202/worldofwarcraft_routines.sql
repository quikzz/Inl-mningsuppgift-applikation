-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: worldofwarcraft
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `races_can_be_classes`
--

DROP TABLE IF EXISTS `races_can_be_classes`;
/*!50001 DROP VIEW IF EXISTS `races_can_be_classes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `races_can_be_classes` AS SELECT 
 1 AS `races_race`,
 1 AS `classes_names`,
 1 AS `classes_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `tier_list`
--

DROP TABLE IF EXISTS `tier_list`;
/*!50001 DROP VIEW IF EXISTS `tier_list`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `tier_list` AS SELECT 
 1 AS `specs_name`,
 1 AS `tiers_char`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `faction_has_races`
--

DROP TABLE IF EXISTS `faction_has_races`;
/*!50001 DROP VIEW IF EXISTS `faction_has_races`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `faction_has_races` AS SELECT 
 1 AS `races_race`,
 1 AS `factions_faction`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `specs_are_roles`
--

DROP TABLE IF EXISTS `specs_are_roles`;
/*!50001 DROP VIEW IF EXISTS `specs_are_roles`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `specs_are_roles` AS SELECT 
 1 AS `specs_name`,
 1 AS `roles_role`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `races_can_be_classes`
--

/*!50001 DROP VIEW IF EXISTS `races_can_be_classes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `races_can_be_classes` AS select `races`.`races_race` AS `races_race`,`classes`.`classes_names` AS `classes_names`,`classes`.`classes_id` AS `classes_id` from (`classes` left join (`races_has_classes` left join `races` on((`races_has_classes`.`races_races_id` = `races`.`races_id`))) on((`races_has_classes`.`classes_classes_id` = `classes`.`classes_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tier_list`
--

/*!50001 DROP VIEW IF EXISTS `tier_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tier_list` AS select `specs`.`specs_name` AS `specs_name`,`tiers`.`tiers_char` AS `tiers_char` from (`specs` join `tiers` on((`tiers`.`tiers_id` = `specs`.`tiers_tiers_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `faction_has_races`
--

/*!50001 DROP VIEW IF EXISTS `faction_has_races`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `faction_has_races` AS select `races`.`races_race` AS `races_race`,`factions`.`factions_faction` AS `factions_faction` from (`races` join `factions` on((`races`.`factions_factions_id` = `factions`.`factions_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `specs_are_roles`
--

/*!50001 DROP VIEW IF EXISTS `specs_are_roles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `specs_are_roles` AS select `specs`.`specs_name` AS `specs_name`,`roles`.`roles_role` AS `roles_role` from (`specs` join `roles` on((`specs`.`roles_roles_id` = `roles`.`roles_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-02 14:45:30
